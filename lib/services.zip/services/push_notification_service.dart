import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

class PushNotificationService {
  PushNotificationService._();

  static final PushNotificationService instance =
  PushNotificationService._();

  final FirebaseMessaging messaging =
      FirebaseMessaging.instance;

  final FirebaseDatabase database =
      FirebaseDatabase.instance;

  StreamSubscription<RemoteMessage>? _foregroundSubscription;

  // =========================================
  // تشغيل خدمة الإشعارات
  // =========================================

  Future<void> initialize() async {
    // طلب صلاحية الإشعارات
    final settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    debugPrint(
      "Notification permission: "
          "${settings.authorizationStatus}",
    );

    // الحصول على FCM Token
    final token = await messaging.getToken();

    debugPrint("================================");
    debugPrint("FCM TOKEN:");
    debugPrint(token);
    debugPrint("================================");

    // استقبال الإشعار والتطبيق مفتوح
    _foregroundSubscription =
        FirebaseMessaging.onMessage.listen(
              (RemoteMessage message) {
            debugPrint(
              "Notification received: "
                  "${message.notification?.title}",
            );

            debugPrint(
              "Message: "
                  "${message.notification?.body}",
            );

            debugPrint(
              "Data: ${message.data}",
            );
          },
        );

    // عند الضغط على الإشعار
    FirebaseMessaging.onMessageOpenedApp.listen(
          (RemoteMessage message) {
        debugPrint(
          "Notification opened: "
              "${message.data}",
        );
      },
    );
  }

  // =========================================
  // الحصول على FCM Token
  // =========================================

  Future<String?> getToken() async {
    return await messaging.getToken();
  }

  // =========================================
  // حفظ FCM Token للمستخدم
  // =========================================

  Future<void> saveFcmToken({
    required String userId,
    required String token,
  }) async {
    await database
        .ref("users")
        .child(userId)
        .update({
      "fcmToken": token,
    });
  }

  // =========================================
  // حفظ Token المستخدم الحالي
  // =========================================

  Future<void> saveCurrentUserToken({
    required String userId,
  }) async {
    final token = await getToken();

    if (token == null || token.isEmpty) {
      debugPrint("FCM Token غير موجود");
      return;
    }

    await saveFcmToken(
      userId: userId,
      token: token,
    );

    debugPrint(
      "تم حفظ FCM Token للمستخدم: $userId",
    );
  }

  // =========================================
  // مراقبة تغير Token
  // =========================================

  StreamSubscription<String> listenTokenChanges(
      Future<void> Function(String token) onToken,
      ) {
    return messaging.onTokenRefresh.listen(
          (String token) async {
        await onToken(token);
      },
    );
  }

  // =========================================
  // إيقاف الخدمة
  // =========================================

  Future<void> dispose() async {
    await _foregroundSubscription?.cancel();
  }
}