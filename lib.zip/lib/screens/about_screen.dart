import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: AppBar(title: const Text('عن التطبيق'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const CircleAvatar(radius: 55, backgroundColor: Colors.white, child: Icon(Icons.local_gas_station, size: 70, color: AppColors.primary)),
      const SizedBox(height: 18),
      const Center(child: Text('نافذة المنتوج النفطي', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
      const SizedBox(height: 8),
      const Center(child: Text('منصة لعرض توفر المنتجات النفطية والمحطات والخدمات والإعلانات التجارية.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: AppColors.subtitle))),
      const SizedBox(height: 22),
      const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('يوفر التطبيق للمواطن معرفة المحطات وتوفر المنتجات ومواقعها، مع إمكانية عرض خدمات وإعلانات تجارية مدفوعة بعد مراجعتها واعتمادها من الإدارة.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, height: 1.6)))),
      const SizedBox(height: 15),
      const ListTile(leading: Icon(Icons.engineering, color: Colors.blue), title: Text('المطور'), subtitle: Text('المطور المهندس سمير صباح')),
      const ListTile(leading: Icon(Icons.verified, color: Colors.orange), title: Text('الإصدار'), subtitle: Text('1.0.0')),
    ]),
  );
}
