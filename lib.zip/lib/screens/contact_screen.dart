import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../services/commercial_service.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() =>
      _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final TextEditingController subject =
  TextEditingController();

  final TextEditingController message =
  TextEditingController();

  final TextEditingController phone =
  TextEditingController();

  bool saving = false;

  @override
  void dispose() {
    subject.dispose();
    message.dispose();
    phone.dispose();
    super.dispose();
  }

  // =====================================================
  // إرسال الرسالة
  // =====================================================

  Future<void> _submit() async {
    // التأكد من تسجيل الدخول
    final User? user =
        FirebaseAuth.instance.currentUser;

    if (user == null) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'يجب تسجيل الدخول أولاً لإرسال الرسالة',
          ),
        ),
      );

      return;
    }

    // التحقق من الرسالة
    final String messageText =
    message.text.trim();

    if (messageText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'اكتب الرسالة أولاً',
          ),
        ),
      );

      return;
    }

    // منع الرسائل الطويلة جداً
    if (messageText.length > 2000) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'الرسالة يجب ألا تتجاوز 2000 حرف',
          ),
        ),
      );

      return;
    }

    if (saving) {
      return;
    }

    setState(() {
      saving = true;
    });

    try {
      await CommercialService.instance.submitContact(
        subject: subject.text.trim(),
        message: messageText,
        phone: phone.text.trim(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'تم إرسال رسالتك بنجاح',
          ),
        ),
      );

      // تنظيف الحقول
      subject.clear();
      message.clear();
      phone.clear();

      Navigator.of(context).pop();
    } on FirebaseException catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر إرسال الرسالة\n'
                'رمز الخطأ: ${e.code}\n'
                '${e.message ?? ''}',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر إرسال الرسالة: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          saving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'تواصل معنا',
        ),
        centerTitle: true,
      ),

      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'أرسل استفسارك أو اقتراحك وسيتم تحويله إلى فريق الإدارة.',
            style: TextStyle(
              fontSize: 16,
            ),
          ),

          const SizedBox(
            height: 16,
          ),

          // =================================================
          // الموضوع
          // =================================================

          TextField(
            controller: subject,
            enabled: !saving,
            textInputAction:
            TextInputAction.next,
            decoration:
            const InputDecoration(
              labelText: 'الموضوع',
              border: OutlineInputBorder(),
              prefixIcon: Icon(
                Icons.subject,
              ),
            ),
          ),

          const SizedBox(
            height: 12,
          ),

          // =================================================
          // الهاتف
          // =================================================

          TextField(
            controller: phone,
            enabled: !saving,
            keyboardType:
            TextInputType.phone,
            textInputAction:
            TextInputAction.next,
            decoration:
            const InputDecoration(
              labelText:
              'رقم الهاتف (اختياري)',
              border: OutlineInputBorder(),
              prefixIcon: Icon(
                Icons.phone,
              ),
            ),
          ),

          const SizedBox(
            height: 12,
          ),

          // =================================================
          // الرسالة
          // =================================================

          TextField(
            controller: message,
            enabled: !saving,
            maxLines: 6,
            maxLength: 2000,
            textInputAction:
            TextInputAction.newline,
            decoration:
            const InputDecoration(
              labelText: 'الرسالة',
              border: OutlineInputBorder(),
              alignLabelWithHint: true,
              prefixIcon: Icon(
                Icons.message,
              ),
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          // =================================================
          // زر الإرسال
          // =================================================

          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed:
              saving ? null : _submit,

              icon: saving
                  ? const SizedBox(
                width: 20,
                height: 20,
                child:
                CircularProgressIndicator(
                  strokeWidth: 2,
                ),
              )
                  : const Icon(
                Icons.send,
              ),

              label: Text(
                saving
                    ? 'جارٍ الإرسال...'
                    : 'إرسال',
              ),
            ),
          ),
        ],
      ),
    );
  }
}