import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../l10n/app_localizations.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _open(BuildContext context, String route) {
    Navigator.pushNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: AppColors.background,

      appBar: AppBar(
        title: Text(l10n.settingsTitle),
        centerTitle: true,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),

        children: [
          Container(
            padding: const EdgeInsets.all(20),

            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF1565C0),
                  Color(0xFF0D47A1),
                ],
              ),
              borderRadius:
              BorderRadius.circular(24),
            ),

            child: Column(
              children: [
                const CircleAvatar(
                  radius: 42,
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.local_gas_station,
                    size: 52,
                    color: AppColors.primary,
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  l10n.appName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 18),

          _section(l10n.general),

          _tile(
            context,
            Icons.language,
            l10n.language,
            l10n.languageSubtitle,
            '/language',
          ),

          _tile(
            context,
            Icons.notifications_active,
            l10n.notifications,
            l10n.notificationsSubtitle,
            '/notifications',
          ),

          const SizedBox(height: 12),

          _section(l10n.ads),

          _tile(
            context,
            Icons.storefront_rounded,
            'لوحة المعلن',
            'إضافة الإعلانات ومتابعتها والمدفوعات والتواصل',
            '/advertiserAccount',
          ),

          _tile(
            context,
            Icons.campaign_outlined,
            l10n.viewAds,
            l10n.viewAdsSubtitle,
            '/commercialAds',
          ),

          const SizedBox(height: 12),

          _section(l10n.supportAndApp),

          _tile(
            context,
            Icons.phone_in_talk,
            l10n.contactUs,
            l10n.contactUsSubtitle,
            '/contact',
          ),

          _tile(
            context,
            Icons.star_rate,
            l10n.rateApp,
            l10n.rateAppSubtitle,
            '/rating',
          ),

          _tile(
            context,
            Icons.info_outline,
            l10n.aboutApp,
            l10n.aboutAppSubtitle,
            '/about',
          ),

          _tile(
            context,
            Icons.privacy_tip_outlined,
            l10n.privacyPolicy,
            l10n.privacyPolicySubtitle,
            '/privacy',
          ),

          _tile(
            context,
            Icons.rule,
            l10n.termsConditions,
            l10n.termsConditionsSubtitle,
            '/terms',
          ),

          Card(
            margin:
            const EdgeInsets.only(top: 12),

            child: ListTile(
              leading: const Icon(
                Icons.verified,
                color: Colors.green,
              ),

              title: Text(
                l10n.appVersion,
              ),

              subtitle:
              const Text('1.0.0'),
            ),
          ),

          const SizedBox(height: 20),

          Center(
            child: Text(
              l10n.developer,
              style: const TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 8,
        right: 4,
      ),

      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
      ),
    );
  }

  Widget _tile(
      BuildContext context,
      IconData icon,
      String title,
      String subtitle,
      String route,
      ) {
    return Card(
      margin:
      const EdgeInsets.only(bottom: 8),

      child: ListTile(
        leading: CircleAvatar(
          backgroundColor:
          AppColors.primary.withValues(
            alpha: .10,
          ),

          child: Icon(
            icon,
            color: AppColors.primary,
          ),
        ),

        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),

        subtitle: Text(subtitle),

        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 16,
        ),

        onTap: () =>
            _open(context, route),
      ),
    );
  }
}
