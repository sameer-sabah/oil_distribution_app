import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class RatingsScreen extends StatelessWidget {
  const RatingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ref = FirebaseDatabase.instance.ref('appRatings');

    return Scaffold(
      appBar: AppBar(
        title: const Text('تقييمات المستخدمين'),
        centerTitle: true,
      ),
      body: StreamBuilder<DatabaseEvent>(
        stream: ref.onValue,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'حدث خطأ:\n${snapshot.error}',
                textAlign: TextAlign.center,
              ),
            );
          }

          if (snapshot.connectionState ==
              ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          final value = snapshot.data?.snapshot.value;

          if (value == null) {
            return const Center(
              child: Text('لا توجد تقييمات حالياً'),
            );
          }

          final raw =
          Map<dynamic, dynamic>.from(value as Map);

          final ratings = raw.entries.toList();

          ratings.sort((a, b) {
            final aDate =
                a.value['createdAt']?.toString() ?? '';
            final bDate =
                b.value['createdAt']?.toString() ?? '';

            return bDate.compareTo(aDate);
          });

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: ratings.length,
            itemBuilder: (context, index) {
              final item =
              Map<dynamic, dynamic>.from(
                ratings[index].value as Map,
              );

              final int rating =
                  int.tryParse(
                    item['rating']?.toString() ?? '0',
                  ) ??
                      0;

              return Card(
                margin:
                const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding:
                  const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.person,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item['userId']
                                  ?.toString() ??
                                  'غير معروف',
                              style:
                              const TextStyle(
                                fontWeight:
                                FontWeight.bold,
                              ),
                            ),
                          ),
                          Row(
                            children: List.generate(
                              5,
                                  (i) => Icon(
                                i < rating
                                    ? Icons.star
                                    : Icons.star_border,
                                size: 22,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      if ((item['comment']
                          ?.toString() ??
                          '')
                          .isNotEmpty)
                        Text(
                          item['comment'].toString(),
                          style:
                          const TextStyle(
                            fontSize: 16,
                          ),
                        ),

                      const SizedBox(height: 8),

                      Text(
                        item['createdAt']
                            ?.toString() ??
                            '',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}