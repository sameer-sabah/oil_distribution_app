import 'package:flutter/material.dart';
import '../services/commercial_service.dart';

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int rating = 5;
  final comment = TextEditingController();
  bool saving = false;

  @override
  void dispose() {
    comment.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => saving = true);
    try {
      await CommercialService.instance.submitRating(
        rating: rating,
        comment: comment.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('شكراً لتقييمك')),
      );
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر إرسال التقييم: $e')),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تقييم التطبيق'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Center(child: Text('ما رأيك بالتطبيق؟', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (index) {
              return IconButton(
                onPressed: () => setState(() => rating = index + 1),
                icon: Icon(Icons.star, size: 42, color: index < rating ? Colors.amber : Colors.grey),
              );
            }),
          ),
          const SizedBox(height: 18),
          TextField(controller: comment, maxLines: 5, decoration: const InputDecoration(labelText: 'ملاحظتك (اختياري)', border: OutlineInputBorder())),
          const SizedBox(height: 20),
          ElevatedButton.icon(onPressed: saving ? null : _submit, icon: const Icon(Icons.star), label: Text(saving ? 'جارٍ الإرسال...' : 'إرسال التقييم')),
        ],
      ),
    );
  }
}
