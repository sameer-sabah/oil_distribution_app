import 'package:flutter/material.dart';
import '../controllers/language_controller.dart';
import '../l10n/app_localizations.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.language),
        centerTitle: true,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),

              child: AnimatedBuilder(
                animation: LanguageController.instance,

                builder: (context, child) {
                  return DropdownButtonFormField<String>(
                    initialValue:
                    LanguageController.instance
                        .locale
                        .languageCode,

                    decoration: InputDecoration(
                      labelText: l10n.chooseLanguage,
                      border: const OutlineInputBorder(),
                    ),

                    items: [
                      DropdownMenuItem(
                        value: 'ar',
                        child: Text(l10n.arabic),
                      ),

                      DropdownMenuItem(
                        value: 'ku',
                        child: Text(l10n.kurdish),
                      ),

                      DropdownMenuItem(
                        value: 'fa',
                        child: Text(l10n.persian),
                      ),

                      DropdownMenuItem(
                        value: 'en',
                        child: Text(l10n.english),
                      ),
                    ],

                    onChanged: (value) async {
                      if (value == null) return;

                      await LanguageController.instance
                          .changeLanguage(value);
                    },
                  );
                },
              ),
            ),
          ),

          const SizedBox(height: 18),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),

              child: Text(
                l10n.chooseLanguage,
                style: const TextStyle(
                  fontSize: 16,
                  height: 1.6,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}