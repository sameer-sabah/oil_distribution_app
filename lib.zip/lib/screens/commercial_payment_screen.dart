import 'package:flutter/material.dart';

import '../services/commercial_service.dart';
import '../services/commercial_payment_settings_service.dart';
import '../services/zaincash_payment_service.dart';

class CommercialPaymentScreen extends StatefulWidget {
  final String entityType;
  final String entityId;
  final double amount;

  const CommercialPaymentScreen({
    super.key,
    required this.entityType,
    required this.entityId,
    required this.amount,
  });

  @override
  State<CommercialPaymentScreen> createState() =>
      _CommercialPaymentScreenState();
}

class _CommercialPaymentScreenState
    extends State<CommercialPaymentScreen> {
  String method = 'اتفاق مع الإدارة';
  final note = TextEditingController();

  bool saving = false;
  bool _settingsLoading = true;
  bool _zainCashEnabled = false;
  bool _gatewayReady = false;
  bool _zainCashBusy = false;

  String _paymentId = '';
  String _transactionId = '';
  String _zainCashStatus = '';

  @override
  void initState() {
    super.initState();
    _loadPaymentSettings();
  }

  @override
  void dispose() {
    note.dispose();
    super.dispose();
  }

  Future<void> _loadPaymentSettings() async {
    try {
      final settings =
      await CommercialPaymentSettingsService
          .instance
          .getSettings();

      if (!mounted) return;

      setState(() {
        _zainCashEnabled =
            settings.zainCashEnabled;
        _gatewayReady =
            settings.gatewayReady;
        _settingsLoading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _settingsLoading = false;
      });
    }
  }

  String _paymentLanguage() {
    final code =
        Localizations.localeOf(context).languageCode;

    if (code == 'en') return 'En';
    if (code == 'ku') return 'Ku';
    return 'Ar';
  }

  Future<void> _payWithZainCash() async {
    if (_zainCashBusy) return;

    setState(() {
      _zainCashBusy = true;
    });

    try {
      final session =
      await ZainCashPaymentService.instance
          .createPayment(
        entityType: widget.entityType,
        entityId: widget.entityId,
        language: _paymentLanguage(),
      );

      if (!mounted) return;

      setState(() {
        _paymentId = session.paymentId;
        _transactionId =
            session.transactionId;
        _zainCashStatus = session.status;
      });

      await ZainCashPaymentService.instance
          .openPaymentPage(
        session.redirectUrl,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'بعد إكمال الدفع في ZainCash ارجع للتطبيق واضغط "تحقق من حالة الدفع".',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر بدء دفع ZainCash: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _zainCashBusy = false;
        });
      }
    }
  }

  Future<void> _checkZainCashPayment() async {
    if (_paymentId.isEmpty ||
        _zainCashBusy) {
      return;
    }

    setState(() {
      _zainCashBusy = true;
    });

    try {
      final result =
      await ZainCashPaymentService.instance
          .inquiry(
        paymentId: _paymentId,
      );

      if (!mounted) return;

      setState(() {
        _transactionId =
            result.transactionId;
        _zainCashStatus =
            result.status;
      });

      if (result.paid) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'تم تأكيد الدفع بنجاح ونشر الإعلان.',
            ),
          ),
        );

        Navigator.of(context).pop();
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'حالة عملية ZainCash حالياً: ${result.status}',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر التحقق من الدفع: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _zainCashBusy = false;
        });
      }
    }
  }

  Future<void> _submit() async {
    setState(() => saving = true);
    try {
      await CommercialService.instance.submitPayment(
        entityType: widget.entityType,
        entityId: widget.entityId,
        amount: widget.amount,
        method: method,
        note: note.text.trim(),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'تم تسجيل طلب الدفع، بانتظار تأكيد الإدارة',
          ),
        ),
      );

      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر تسجيل الدفع: $e',
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => saving = false);
      }
    }
  }

  Widget _zainCashCard() {
    if (_settingsLoading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(18),
          child: Center(
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    if (!_zainCashEnabled) {
      return const SizedBox.shrink();
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.stretch,
          children: [
            const Row(
              children: [
                Icon(
                  Icons.account_balance_wallet_rounded,
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'الدفع الإلكتروني عبر ZainCash',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              _gatewayReady
                  ? 'البوابة مفعلة. المبلغ يؤخذ من السعر المعتمد في الخادم وليس من الهاتف.'
                  : 'تم تفعيل ZainCash من الإعدادات، لكن حالة جاهزية البوابة ما زالت غير مؤكدة. سيقوم الخادم بالتحقق قبل بدء العملية.',
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed:
              _zainCashBusy
                  ? null
                  : _payWithZainCash,
              icon: const Icon(
                Icons.open_in_new_rounded,
              ),
              label: Text(
                _zainCashBusy
                    ? 'جارٍ الاتصال...'
                    : 'Pay with ZainCash',
              ),
            ),
            if (_paymentId.isNotEmpty) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed:
                _zainCashBusy
                    ? null
                    : _checkZainCashPayment,
                icon: const Icon(
                  Icons.verified_rounded,
                ),
                label: const Text(
                  'تحقق من حالة الدفع',
                ),
              ),
              if (_zainCashStatus.isNotEmpty)
                Padding(
                  padding:
                  const EdgeInsets.only(top: 8),
                  child: Text(
                    'الحالة: $_zainCashStatus',
                  ),
                ),
              if (_transactionId.isNotEmpty)
                Padding(
                  padding:
                  const EdgeInsets.only(top: 4),
                  child: SelectableText(
                    'Transaction ID: $_transactionId',
                    style: const TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الدفع والفاتورة'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(
                    Icons.receipt_long,
                    size: 55,
                    color: Colors.blue,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'المبلغ المعتمد',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    '${widget.amount.toStringAsFixed(0)} د.ع',
                    style: const TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),

          _zainCashCard(),

          const SizedBox(height: 18),
          const Divider(),
          const SizedBox(height: 8),

          const Text(
            'طرق الدفع اليدوية الحالية',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: method,
            items: const [
              DropdownMenuItem(
                value: 'اتفاق مع الإدارة',
                child: Text('اتفاق مع الإدارة'),
              ),
              DropdownMenuItem(
                value: 'تحويل مصرفي',
                child: Text('تحويل مصرفي'),
              ),
              DropdownMenuItem(
                value: 'طريقة أخرى',
                child: Text('طريقة أخرى'),
              ),
            ],
            onChanged: (value) {
              setState(() {
                method = value ?? method;
              });
            },
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: note,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText:
              'ملاحظات أو رقم التحويل',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed:
            saving ? null : _submit,
            icon: const Icon(Icons.send),
            label: Text(
              saving
                  ? 'جارٍ التسجيل...'
                  : 'تأكيد إرسال الدفع اليدوي',
            ),
          ),
        ],
      ),
    );
  }
}
