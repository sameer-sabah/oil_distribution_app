import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  String _tr(BuildContext context, String key) {
    final lang = Localizations.localeOf(context).languageCode;

    const translations = <String, Map<String, String>>{
      'ar': {
        'appName': 'نافذة المنتوج النفطي',
        'home': 'الرئيسية',
        'login': 'تسجيل الدخول',
        'citizen': 'دخول المواطن',
        'ads': 'الإعلانات',
        'services': 'الخدمات',
        'notifications': 'الإشعارات',
        'settings': 'الإعدادات',
        'logout': 'تسجيل الخروج',
      },
      'en': {
        'appName': 'Oil Product Window',
        'home': 'Home',
        'login': 'Login',
        'citizen': 'Citizen Access',
        'ads': 'Advertisements',
        'services': 'Services',
        'notifications': 'Notifications',
        'settings': 'Settings',
        'logout': 'Logout',
      },
      'ku': {
        'appName': 'پەنجەرەی بەرهەمی نەوتی',
        'home': 'سەرەکی',
        'login': 'چوونەژوورەوە',
        'citizen': 'چوونەژوورەوەی هاووڵاتی',
        'ads': 'ڕیکلامەکان',
        'services': 'خزمەتگوزارییەکان',
        'notifications': 'ئاگادارکردنەوەکان',
        'settings': 'ڕێکخستنەکان',
        'logout': 'چوونەدەرەوە',
      },
      'fa': {
        'appName': 'پنجره محصولات نفتی',
        'home': 'صفحه اصلی',
        'login': 'ورود',
        'citizen': 'ورود شهروند',
        'ads': 'تبلیغات',
        'services': 'خدمات',
        'notifications': 'اعلان‌ها',
        'settings': 'تنظیمات',
        'logout': 'خروج',
      },
    };

    return translations[lang]?[key] ?? translations['ar']![key] ?? key;
  }

  @override
  Widget build(BuildContext context) => Drawer(
    child: SafeArea(
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 20),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
            ),
          ),
          child: Column(children: [
            const CircleAvatar(
              radius: 44,
              backgroundColor: Colors.white,
              child: Icon(
                Icons.local_gas_station,
                size: 54,
                color: Color(0xFF1565C0),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _tr(context, 'appName'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ]),
        ),
        ListTile(
          leading: const Icon(Icons.home),
          title: Text(_tr(context, 'home')),
          onTap: () => Navigator.pop(context),
        ),
        ListTile(
          leading: const Icon(Icons.person),
          title: Text(_tr(context, 'login')),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/login');
          },
        ),
        ListTile(
          leading: const Icon(Icons.public),
          title: Text(_tr(context, 'citizen')),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/citizen');
          },
        ),
        ListTile(
          leading: const Icon(Icons.campaign),
          title: Text(_tr(context, 'ads')),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/commercialAds');
          },
        ),
        ListTile(
          leading: const Icon(Icons.notifications),
          title: Text(_tr(context, 'notifications')),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/notifications');
          },
        ),
        ListTile(
          leading: const Icon(Icons.settings),
          title: Text(_tr(context, 'settings')),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/settings');
          },
        ),
        const Spacer(),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: Text(
            _tr(context, 'logout'),
            style: const TextStyle(color: Colors.red),
          ),
          onTap: () async {
            await AuthService.instance.logout();
            if (!context.mounted) return;
            Navigator.pushNamedAndRemoveUntil(
              context,
              '/login',
                  (route) => false,
            );
          },
        ),
      ]),
    ),
  );
}
